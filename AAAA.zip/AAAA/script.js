// Contoh animasi interaktif atau kalkulasi harga:
function hitungHarga(jumlah, hargaPerUnit) {
  return jumlah * hargaPerUnit;
}

console.log(hitungHarga(50, 35)); // Output: 1750